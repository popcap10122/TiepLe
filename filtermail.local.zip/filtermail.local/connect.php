<?php 

	try{
		$table='dsemail';
		$location_file="email\dsmail.csv";
		$db = new PDO('sqlite:db\test.db');
		$db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	    // print("Created $table Table.\n");
		$file = fopen($location_file,"r");
		while(!feof($file)){
			 $dsmail=fgetcsv($file);
			 if (is_array($dsmail) || is_object($dsmail))
			{
			     foreach ($dsmail as $value) {
			 	  // echo $value." ";
			 	  $sql="select count(*) from  $table";
			 	  echo $sql;
			 	  $result=$db->query($sql." where email = '$value' ");
			 	  $numrow=$result->fetchColumn(); 
				  // echo $numrow;
				  if($numrow > 0){
				  	return 0;
				  }
				  else{
				  	$sth=$db->prepare("insert into $table (email) values(:email)");
		 		 	 $sth->execute(array(
		 		 	':email'=>$value
				    ));
		 		 	 echo'Iserted';
				  }			 	 	
				}
			}			 
		}
		fclose($file);
		 // $sth=$db->prepare('delete from dsemail');
		 // $sth->exec($sth);
	}
	catch (PDOException $e){
		echo 'Exception'.$e->getMessage();
	}
?>