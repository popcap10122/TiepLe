<?php 
	if($_FILES["file2"]["name"]!='')
	{
		$test =explode(".",$_FILES["file2"]["name"]);
		$extension = end($test);
		$name=$_FILES["file2"]["name"];
		$location ='./db/'.$name;
		move_uploaded_file($_FILES["file2"]["tmp_name"],$location);	
		$db = new PDO('sqlite:db\test.db');
		$db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		$file= fopen($location,"r");
		echo $location;
		while(!feof($file)){
			 $dsmail=fgetcsv($file);
			 if (is_array($dsmail) || is_object($dsmail))
			{
			     foreach ($dsmail as $value) {
			 	 	$sth=$db->prepare('insert into tabletest(email) values(:email)');
		 		 	 $sth->execute(array(
		 		 	':email'=>$value
				    ));
				}
			}			 
		}
		fclose($file);
	}
 ?>