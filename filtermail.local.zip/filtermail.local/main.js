$(document).ready(function(){
	$(document).on('change','#file',function(){
		var property = document.getElementById("file").files[0];
		var image_name = property.name;
		var image_extension = image_name.split('.').pop().toLowerCase();
		var image_size = property.size;
		if(jQuery.inArray(image_extension,['csv','xlsx'])== -1){
			alert("Chỉ hỗ trợ file định dạng CSV, XLSX");
			return false;
		}
		if(image_size>2000000)
		{
			alert("Dung lượng file tối đa 2M");
		}
		else
		{
			if(jQuery.inArray(image_extension,['csv'])== 0){
				var form_data = new FormData();
				form_data.append("file",property);
				$.ajax({
					url:'pscsv1.php',
					method:"post",
					data:form_data,
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(){
						$('#uploaded_image').html("<label class='text-success'> Img uploading...</label>");
					},
					success:function(data){
						// alert(data);
						$('#uploaded_image').html(data);
						$('#content').html(data);
					}
				});
			}
			else
			{
				var form_data = new FormData();
				form_data.append("file",property);
				$.ajax({
					url:'psxls1.php',
					method:"post",
					data:form_data,
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(){
						$('#uploaded_image').html("<label class='text-success'> Img uploading...</label>");
					},
					success:function(data){
						// alert(data);
						$('#uploaded_image').html(data);
						$('#content').html(data);
					}
				});
			}
		}
	});
	$(document).on('change','#file2',function(){
		var property = document.getElementById("file2").files[0];
		var image_name = property.name;
		var image_extension = image_name.split('.').pop().toLowerCase();
		if(jQuery.inArray(image_extension,['csv','xlsx'])== -1){
			alert("Chỉ hỗ trợ file định dạng CSV, XLSX");
			return false;
		}
		var image_size = property.size;
		if(image_size>2000000)
		{
			alert("Dung lượng file tối đa 2M");
		}
		else
		{
			if(jQuery.inArray(image_extension,['csv'])== 0)
			{
				var form_data = new FormData();
				form_data.append("file2",property);
				$.ajax({
					url:'importdb.php',
					method:"post",
					data:form_data,
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(){
						$('#uploaded_file2').html("<label class='text-success'> Img uploading...</label>");
					},
					success:function(data){
						// alert(data);
						// $('#uploaded_file').html(data);
						// $('#content2').html(data);
					}
				});
			}
			else{
				var form_data = new FormData();
				form_data.append("file2",property);
				$.ajax({
					url:'psxls2.php',
					method:"post",
					data:form_data,
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(){
						$('#uploaded_file2').html("<label class='text-success'> Img uploading...</label>");
					},
					success:function(data){
						// alert(data);
						$('#uploaded_file').html(data);
						$('#content2').html(data);
					}
				});
			}
			
		}
	});

	$(document).on('click','#btnsosanh',function(){
		if($('#content').text() =='' && $('#content2').text() =='')
		{
			alert('vui long kiem tra file up');	
		}
		else{
			$('#downfile').css("display","block");		
		}
	});
	$(document).on('click','#btnload',function(){
		$.ajax({
			url:'show.php',
			// data:form_data,
			contentType:false,
			cache:false,
			processData:false,
			success:function(data){
				// console.log(data);
				$('#uploaded_file').html(data);
				$('#content2').html(data);

			}
		});
	});
	$(document).on('click','#update',function(){
		$.ajax({
			url:'connect.php',
			// data:form_data,
			contentType:false,
			cache:false,
			processData:false,
			success:function(data){
				// console.log(data);
				// $('#uploaded_file').html(data);
				// $('#content2').html(data);

			}
		});
	});
});
