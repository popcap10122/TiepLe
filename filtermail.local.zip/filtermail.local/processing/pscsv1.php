<?php 
	if($_FILES["file"]["name"]!='')
	{
		$test =explode(".",$_FILES["file"]["name"]);
		$extension = end($test);
		$name=rand(100,999).'.'.$extension;
		$location ='./uploads/'.$name;
		move_uploaded_file($_FILES["file"]["tmp_name"],$location);
		$csv= file_get_contents($location);
		$array = array_map("str_getcsv", explode("\n", $csv));
		// $json = json_encode($array);
		//print_r($json);
		 foreach ($array as $key => $ds) {
		 	foreach ($ds as $key => $value) {
		 		echo $value." ";
		 	}
			
		}
		// echo '<img src="'.$location.'"height="150" width="225" class="img-thumbnail"/>';
		
	}
 ?>