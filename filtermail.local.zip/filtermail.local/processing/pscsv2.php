<?php 
	if($_FILES["file2"]["name"]!='')
	{
		$test =explode(".",$_FILES["file2"]["name"]);
		$extension = end($test);
		$name=rand(100,999).'.'.$extension;
		$location ='./uploads/'.$name;
		move_uploaded_file($_FILES["file2"]["tmp_name"],$location);
		$csv= file_get_contents($location);
		$array2 = array_map("str_getcsv", explode("\n", $csv));
		$json = json_encode($array2);
		// print_r($json);
		foreach ($array2 as $key => $ds) {
		 	foreach ($ds as $key => $value) {
		 		echo $value." ";
		 	}
			
		}
		// echo '<img src="'.$location.'"height="150" width="225" class="img-thumbnail"/>';
		
	}
 ?>