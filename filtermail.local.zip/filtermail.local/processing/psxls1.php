<?php 
	require_once "Classes/PHPExcel.php";
	if($_FILES["file"]["name"]!='')
	{
		$test =explode(".",$_FILES["file"]["name"]);
		$extension = end($test);
		$name=rand(100,999).'.'.$extension;
		$location ='./uploads/'.$name;
		move_uploaded_file($_FILES["file"]["tmp_name"],$location);
		$csv= file_get_contents($location);
		$array2 = array_map("str_getcsv", explode("\n", $csv));
		$json = json_encode($array2);

		$filename=$location;
		$type = PHPExcel_IOFactory::identify($filename);
		$objReader =PHPExcel_IOFactory::createReader($type);
		$excelObj = $objReader->load($filename);
		
		foreach($excelObj->getWorksheetIterator() as $sheetexcel){
			$array_sheet[$sheetexcel->getTitle()]=$sheetexcel->toArray();
						
		}
		foreach ($array_sheet['Sheet1'] as $key => $ds) {
			foreach ($ds as $key => $value) {
				echo $value." ";
			}
		}
		// print_r($array_sheet['Sheet1']);
		// echo '<img src="'.$location.'"height="150" width="225" class="img-thumbnail"/>';
		
	}
 ?>