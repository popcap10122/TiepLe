<?php 
	try {
		$db = new PDO('sqlite:db\test.db');
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql='select * from dsemail';
		$result=$db->query($sql);
		foreach ($result as $email) {			
			echo $email['email']." ";
		}
	} catch (PDOException $e) {
		echo $e->getMessage();
	}
?>