<?php
$numbers = range(1, 49);
shuffle($numbers);
$numbers = array_slice($numbers, 0, 6);
print_r($numbers);
?>
<html>
	<head></head>
	<body>
	<marquee bgcolor="yellow" direction="up"  scrolldelay="-111" width="2%" height="10%"><i><font color="blue" direction="up" scrolldelay="40"><strong><?php shuffle($numbers);$numbers = array_slice($numbers, 0, 6);foreach ($numbers as $num) {
		echo $num;
		# code...
	}  ?></strong>  </font></i></marquee> 
	<script>
		var today = new Date();
 document.getElementById('time').innerHTML=today;
	</script>
	</body>
</html>